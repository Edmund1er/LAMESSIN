import 'package:flutter/material.dart';
import '../../SERVICES_/api_service.dart';
import '../../MODELS_/utilisateur_model.dart'; 

class EditProfilPage extends StatefulWidget {
  final Patient patient; 
  const EditProfilPage({super.key, required this.patient});

  @override
  State<EditProfilPage> createState() => _EditProfilPageState();
}

class _EditProfilPageState extends State<EditProfilPage> {
  late TextEditingController _prenomController;
  late TextEditingController _nomController;
  late TextEditingController _telController;
  bool _enChargement = false;

  final Color couleurVerte = const Color.fromARGB(255, 78, 192, 17);
  final Color couleurBleue = const Color(0xFF0056b3);

  @override
  void initState() {
    super.initState();
    _prenomController = TextEditingController(text: widget.patient.compteUtilisateur.firstName);
    _nomController = TextEditingController(text: widget.patient.compteUtilisateur.lastName);
    _telController = TextEditingController(text: widget.patient.compteUtilisateur.numeroTelephone);
  }

  @override
  void dispose() {
    _prenomController.dispose();
    _nomController.dispose();
    _telController.dispose();
    super.dispose();
  }

  void _sauvegarder() async {
    if (_prenomController.text.trim().isEmpty || _nomController.text.trim().isEmpty || _telController.text.trim().isEmpty) {
      _afficherMessage("Veuillez remplir tous les champs obligatoires", Colors.red);
      return;
    }

    setState(() => _enChargement = true);
    
    Map<String, dynamic> data = {
      "first_name": _prenomController.text.trim(),
      "last_name": _nomController.text.trim(),
      "numero_telephone": _telController.text.trim(),
    };

    bool succes = await ApiService.updateProfil(data);

    if (mounted) {
      setState(() => _enChargement = false);
      if (succes) {
        Navigator.pop(context, true);
      } else {
        _afficherMessage("Erreur lors de la mise à jour", Colors.red);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F9FF),
      appBar: AppBar(
        title: const Text("Modifier Profil", style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        foregroundColor: couleurBleue,
        elevation: 1,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 10,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [couleurVerte.withOpacity(0.8), couleurBleue]),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const SizedBox(height: 20),
                  const Text("Vos coordonnées", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blueGrey)),
                  const SizedBox(height: 30),
                  _buildPremiumField(_prenomController, "Prénom", Icons.person_outline_rounded),
                  const SizedBox(height: 15),
                  _buildPremiumField(_nomController, "Nom", Icons.person_outline_rounded),
                  const SizedBox(height: 15),
                  _buildPremiumField(_telController, "Numéro de téléphone", Icons.phone_android_rounded, keyboard: TextInputType.phone),
                  const SizedBox(height: 45),
                  _buildBoutonSauvegarder(),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBoutonSauvegarder() {
    return SizedBox(
      width: double.infinity,
      height: 55,
      child: ElevatedButton(
        onPressed: _enChargement ? null : _sauvegarder,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color.fromARGB(255, 78, 192, 17),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          elevation: 3,
        ),
        child: _enChargement 
          ? const CircularProgressIndicator(color: Colors.white) 
          : const Text("SAUVEGARDER LES MODIFICATIONS", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
      ),
    );
  }

  Widget _buildPremiumField(TextEditingController controller, String label, IconData icon, {TextInputType keyboard = TextInputType.text}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [BoxShadow(color: couleurBleue.withOpacity(0.03), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: TextField(
        controller: controller,
        keyboardType: keyboard,
        style: const TextStyle(fontWeight: FontWeight.w500),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: Colors.grey, fontSize: 14),
          prefixIcon: Icon(icon, color: couleurBleue),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
          filled: true,
          fillColor: Colors.white,
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: couleurBleue, width: 1.5)),
        ),
      ),
    );
  }

  void _afficherMessage(String msg, Color couleur) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: couleur, behavior: SnackBarBehavior.floating));
  }
}